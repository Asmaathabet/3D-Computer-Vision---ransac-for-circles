#include <iostream>
#include <random>
#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/core/types.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

using namespace cv;

// 1- Generate Data
std::vector<Point2f> generate_data(double noise, int point_number, int outlier_number, double circle_radius, Size size) {
    // empty vector to store the generated points
    std::vector<Point2f> points;

    // Generate random circle center
    int random_number = std::rand() % 10 + 1;
    Point2f circle_center(static_cast<float>(size.width / random_number), static_cast<float>(size.height / random_number));

    // Generate points on the circle with noise
    for (int i = 0; i < point_number; ++i) {
        double angle = static_cast<double>(i) / point_number * 2 * CV_PI;
        float x = circle_center.x + static_cast<float>(circle_radius * cos(angle));
        float y = circle_center.y + static_cast<float>(circle_radius * sin(angle));
        // Add the noise
        x += static_cast<float>(noise * ((rand() % 2000 - 1000) / 1000.0));
        y += static_cast<float>(noise * ((rand() % 2000 - 1000) / 1000.0));
        points.push_back(Point2f(x, y));
    }

    // Generate random outliers
    for (int i = 0; i < outlier_number; ++i) {
        points.push_back(Point2f(static_cast<float>(rand() % size.width), static_cast<float>(rand() % size.height)));
    }

    return points;
}

// 2- Create RANSAC algorithm to fit the circle
std::pair<Point2f, float> ransac_circle(const std::vector<Point2f>& points, int num_iterations, double threshold) {
    int best_inlier_count = 0;
    Point2f best_center;
    float best_radius;

    for (int iteration = 0; iteration < num_iterations; ++iteration) {
        // choose 3 random points to fit a circle
        std::vector<Point2f> sampled_points;
        for (int i = 0; i < 3; ++i) {
            int index = rand() % points.size();
            sampled_points.push_back(points[index]);
        }

        // Solve the linear system Ax = b
        Mat A(3, 3, CV_64F);
        Mat b(3, 1, CV_64F);

        for (int i = 0; i < 3; ++i) {
            A.at<double>(i, 0) = 2.0 * sampled_points[i].x;
            A.at<double>(i, 1) = 2.0 * sampled_points[i].y;
            A.at<double>(i, 2) = -1.0;
            b.at<double>(i, 0) = sampled_points[i].x * sampled_points[i].x + sampled_points[i].y * sampled_points[i].y;
        }

        Mat x;
        solve(A, b, x);

        // Get out the circle parameters
        double a_value = x.at<double>(0, 0);
        double b_value = x.at<double>(1, 0);
        double c_value = x.at<double>(2, 0);

        double radius = sqrt(a_value * a_value + b_value * b_value - 4 * c_value);

        Point2f center(a_value / 2, b_value / 2);

        // Count inliers based on the threshold
        int inlier_count = 0;
        for (const Point2f& point : points) {
            float distance = norm(point - center) - radius;
            if (std::abs(distance) < threshold) {
                inlier_count++;
            }
        }

        // Update the best circle
        if (inlier_count > best_inlier_count) {
            best_inlier_count = inlier_count;
            best_center = center;
            best_radius = radius;
        }
    }

    return std::make_pair(best_center, best_radius);
}

int main() {
    // Parameters
    double noise = 5.0;
    int point_number = 100;
    int outlier_number = 20;
    double circle_radius = 100.0;
    Size size(800, 800);
    int ransac_iterations = 5000;
    double ransac_threshold = 10.0;

    // Seed the random number generator
    srand(static_cast<unsigned>(time(nullptr)));

    // Generate data
    std::vector<Point2f> data = generate_data(noise, point_number, outlier_number, circle_radius, size);

    // Use RANSAC to fit a circle to the data
    std::pair<Point2f, float> best_circle = ransac_circle(data, ransac_iterations, ransac_threshold);

    // Create an image to see the results
    Mat image(size, CV_8UC3, Scalar(255, 255, 255));

    // show the generated points
    for (const Point2f& point : data) {
        circle(image, point, 2, Scalar(0, 0, 255), FILLED);
    }

    // show the RANSAC fitted circle
    if (best_circle.second > 0) {
        circle(image, best_circle.first, static_cast<int>(best_circle.second), Scalar(0, 255, 0), 2);
    }

    // Display the image
    imshow("RANSAC for Circles", image);
    waitKey(0);

    return 0;
}
